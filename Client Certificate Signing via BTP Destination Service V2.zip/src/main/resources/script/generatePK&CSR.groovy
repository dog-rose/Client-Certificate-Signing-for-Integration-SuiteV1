import com.sap.gateway.ip.core.customdev.util.Message
import java.security.KeyPairGenerator
import java.security.KeyPair
import java.security.PrivateKey
import java.util.Base64
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.operator.ContentSigner
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.bouncycastle.pkcs.PKCS10CertificationRequest
import org.bouncycastle.pkcs.jcajce.JcaPKCS10CertificationRequestBuilder
def Message processData(Message message) {
    // ── 1. Generate RSA Key Pair ──────────────────────────────────────────
    KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA")
    keyGen.initialize(2048)
    KeyPair keyPair = keyGen.generateKeyPair()
    PrivateKey privateKey = keyPair.getPrivate()
    // ── 2. Encode Private Key to PEM format and store as property ─────────
    String base64Key = Base64.getMimeEncoder(64, "\n".getBytes()).encodeToString(privateKey.getEncoded())
    String privateKeyPEM = "-----BEGIN PRIVATE KEY-----\n" + base64Key + "\n-----END PRIVATE KEY-----"
    message.setProperty("privateKeyPEM", privateKeyPEM)
    // ── 3. Build and sign the CSR ─────────────────────────────────────────
    X500Name subject = new X500Name("CN=placeholder, O=placeholder, C=US")
    ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").build(keyPair.getPrivate())
    PKCS10CertificationRequest csr = new JcaPKCS10CertificationRequestBuilder(subject, keyPair.getPublic()).build(signer)
    // ── 4. Build CSR PEM, Base64-encode it and store as property ──────────
    String csrPEM = "-----BEGIN CERTIFICATE REQUEST-----\n" +
                    Base64.getMimeEncoder(64, "\n".getBytes()).encodeToString(csr.getEncoded()) +
                    "\n-----END CERTIFICATE REQUEST-----"
    message.setProperty("csrBase64", Base64.getEncoder().encodeToString(csrPEM.getBytes("UTF-8")))
    // ── 5. Set success message as body ────────────────────────────────────
    message.setBody("Private key and CSR generated successfully!")
    return message
}