import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def csrPEM = message.getProperty("csrPEM")

    if (csrPEM != null) {
        def csrBase64 = csrPEM.toString().bytes.encodeBase64().toString()
        message.setProperty("csrBase64", csrBase64)
    }

    return message
}