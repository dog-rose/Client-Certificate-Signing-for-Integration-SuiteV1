import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper

def Message processData(Message message) {
    // ── 1. Parse token response body (streamed) ────────────────────────────
    def reader = message.getBody(java.io.Reader.class)
    def json = new JsonSlurper().parse(reader)

    // ── 2. Extract access token ────────────────────────────────────────────
    String accessToken = json.access_token
    if (!accessToken) {
        throw new Exception("Failed to retrieve access token.")
    }

    // ── 3. Set as exchange property ────────────────────────────────────────
    message.setProperty("accessToken", accessToken)

    // ── 4. Clear body ──────────────────────────────────────────────────────
    message.setBody("Auth Token Retrieved Successfully!")

    return message
}