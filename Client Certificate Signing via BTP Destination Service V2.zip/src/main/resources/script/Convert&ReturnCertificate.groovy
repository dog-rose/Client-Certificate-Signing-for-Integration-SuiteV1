import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import java.util.Base64

def Message processData(Message message) {
    // ── 1. Parse signing API response (streamed to avoid JSONSlurper warning) ──
    def reader = message.getBody(java.io.Reader.class)
    def json = new JsonSlurper().parse(reader)

    // ── 2. Extract Content field (Base64 encoded certificate) ──────────────
    String certBase64 = json.Content
    if (!certBase64) {
        throw new Exception("Signing API did not return a certificate.")
    }

    // ── 3. Decode from Base64 → PEM ────────────────────────────────────────
    byte[] certBytes = Base64.getDecoder().decode(certBase64)
    String certPEM = new String(certBytes)

    // ── 4. Retrieve Certificate Name from Exchange Property ─────────────────
    String certName = message.getProperty("CertName")
    if (!certName) {
        throw new Exception("CertName exchange property is missing or empty.")
    }

    // ── 5. Construct JSON body ─────────────────────────────────────────────
    def body = """{"name": "${certName}", "signed cert": "${certPEM.replace("\n", "\\n")}"}"""
    message.setBody(body)
    
        // ── 6. Add actual content as attachments ───────────────────────────────
def messageLog = messageLogFactory.getMessageLog(message)
messageLog?.addAttachmentAsString("${certName}.pem", certPEM, "text/plain")



    return message
}